'use strict'

var chai = require("chai");
var expect = chai.expect;

chai.should();

function returnsName(name){
	return name;

};

describe("firstunittest",function(){
	it("returns a name passed to the function",function(){
		returnsName('seema').should.equal('seema');
	});
});

