var restify = require("restify"),product=require("./product");

var server = restify.createServer({

	name:"simple restify server"
});

server.use(function(req,res,next){
	console.log(req.method+"  "+req.url);
	return next();
});

server.use(restify.bodyParser());

server.get("api/product",product.get);
server.get("api/product/:id",product.getById);
server.post("api/product",product.post);
server.put("api/product/:id",product.put);
server.del("api/product/:id",product.del);

server.listen(3000,function(){

	console.log("Server started");
});
