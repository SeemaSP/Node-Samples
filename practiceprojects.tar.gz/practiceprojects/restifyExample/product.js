function productController(){
	this.store = [];
	var findProductById = function(req){
		var found = this.store.filter(function(p){
			return p.Id === parseInt(req.params.id);
		});
	if(found && found.length>0){
		return found[0];
	}
	return null;
	};
	
	this.get = function(req,res,next){
		res.send(200,this.store);
		return next();
	};
        this.getById = function(req,res,next){
		var found = findProductById(req);
		if(found){
			res.send(200,found);
		}
		else{
			res.send(400,"Product not found");
		}
		return next();
        };
        this.post = function(req,res,next){
		if(!req.body.hasOwnProperty("id")||!req.body.hasOwnProperty("name")){
			res.send(500);
		
		}
		else{
			this.store.push({
				id:parseInt(req.body.id),
				name:req.body.name
			});
		}
		return next();
        };
        this.put = function(req,res,next){
		if(!req.body.hasOwnProperty("name")){
			res.send(500);
			return next();
		}
		var found = findProductById(req);
		if(found){
			found.name = req.body.name;
			res.send(200,found);
		}else{
			res.send(400,"Product not found");
		}
		return next();
        };
        this.del = function(req,res,next){
		this.store = this.store.filter(function(p){
			return p.Id === parseInt(req.params.id);	
		});
		res.send(200);
		return next();
        };



};

module.exports = new  productController();
